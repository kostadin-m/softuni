class Zoo:
    def __init__(self, name, budget, animal_capacity,workers_capacity):
        self.name = name
        self.__budget = budget
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.workers = []
        self.animals = []

    def add_animal(self, animal, animal_price):
        if self.__budget - animal_price < 0:
            return f"Not enough budget"
        if len(self.animals) == self.__animal_capacity:
            return f"Not enough space for animal"

        self.__budget -= animal_price
        self.animals.append(animal)
        return f"{animal.name} the {type(animal).__name__} added to the zoo"

    def hire_worker(self, worker):
        if self.__workers_capacity == len(self.workers):
            return f"Not enough space for worker"
        self.workers.append(worker)
        return f'{worker.name} the {type(worker).__name__} hired successfully'


    def fire_worker(self, worker_name):
        x = [x for x in self.workers if x.name == worker_name]
        if not x:
            return f"There is no {worker_name} in the zoo"

        self.workers.remove(x[0])
        return f"{worker_name} fired successfully"

    def pay_workers(self):
        all_salaries = sum(x.salary for x in self.workers)
        if self.__budget - all_salaries < 0:
            return "You have no budget to pay your workers. They are unhappy"
        self.__budget -= all_salaries
        return f"You payed your workers. They are happy. Budget left: {self.__budget}"

    def tend_animals(self):
        price_for_animal_care = sum(x.money_for_care for x in self.animals)
        if self.__budget - price_for_animal_care < 0:
            return f"You have no budget to tend the animals. They are unhappy."
        self.__budget -= price_for_animal_care
        return f"You tended all the animals. They are happy. Budget left: {self.__budget}"

    def profit(self, profit):
        self.__budget += profit

    def animals_status(self):
        result = f"You have {len(self.workers)} animals"
        animals = {'Lions': [], 'Tigers': [], 'Cheetahs': []}

        for animal in self.animals:
            if self.find_obj('Lion', animal):
                animals['Lions'].append(animal)
            elif self.find_obj('Tiger', animal):
                animals['Tigers'].append(animal)
            elif self.find_obj('Cheetah', animal):
                animals['Cheetahs'].append(animal)
        return self.__result(animals, 'animals', self.animals)

    def workers_status(self):
        workers = {'Keepers': [], 'Caretakers': [], 'Vets': []}
        for worker in self.workers:
            if self.find_obj('Keeper', worker):
                workers['Keepers'].append(worker)
            if self.find_obj('Caretaker', worker):
                workers['Caretakers'].append(worker)
            if self.find_obj('Vet', worker):
                workers['Vets'].append(worker)
        return self.__result(workers, 'workers', self.workers)

    def find_obj(self, obj, main_obj):
        if main_obj.__class__.__name__ == obj:
            return True
        return False

    def __result(self, obj_dict, type, type_list):
        result = f"You have {len(type_list)} {type}"
        for key, value in obj_dict.items():
            result += f"\n----- {len(value)} {key}:\n"
            result += '\n'.join([repr(x) for x in value])
        return result
